# a1.py

# Starter code for assignment 1 in ICS 32 Programming with Software Libraries in Python

# Replace the following placeholders with your information.

# Eliya Khajeie 
# ekhajeie@uci.edu
# 85362437

from pathlib import Path
from pathlib import PurePath
import os 

def opt_C(user_path, extension_path):
    user_string = ''.join(user_path)
    extension_string = ''.join(extension_path)
    full_path = os.path.join(user_string, extension_string +".dsu")
    p = Path(full_path)
    print(p)
    p = p.with_suffix(".dsu")
    p.touch()
    run()

def opt_D(user_path): #good 
    p = Path("".join(user_path))
    if p.exists() and p.is_file() and p.suffix == ".dsu":
        p.unlink()
        print(f'{p} DELETED')
    else:
        print("ERROR")
        run()

def opt_R(user_path): #good
    p = Path("".join(user_path))
    if not p.is_file() or p.suffix != (".dsu"):
        print("ERROR")
    else:
        try:
            with p.open("r") as file:
                lines = file.read()
                if len(lines) == 0:
                    print("EMPTY")
                else:
                    print(lines,end="")
        except FileNotFoundError:
            print("ERROR")

def opt_L(fullpath): #works 
    file_list, directory_list = [], []
    inputp = Path("".join(fullpath))
    if command == "L":
        try:
            for firstpath in inputp.iterdir():
                if firstpath.is_file() == True:
                    file_list.append(firstpath)
                if firstpath.is_file() != True:
                    directory_list.append(firstpath)
            total_list = file_list + directory_list
            if optionind1 not in ["r", "f", "e", "s"] and len(il) >= 4:
                for fil in file_list:
                    print(fil)
                for dir in directory_list:
                    print(dir)
            else:
                try: 
                    if optionind1 == "r":
                        global emp_file
                        emp_file = file_list
                        r(directory_list)
                        if optionind2 == None:
                            for i in emp_file:
                                print(i)
                        if optionind2 is not None:
                            if optionind2 == "f": #option2 should b good 
                                f(emp_file)
                            elif optionind2 == "s": 
                                s(emp_file)
                            elif optionind2 == "e":
                                e(emp_file)

                    elif optionind1 == "f":
                        f(file_list)
                    elif optionind1 == "e":
                        e(total_list)
                    elif optionind1 == "s":
                        s(total_list)
                except (IndexError):
                    pass
        except FileNotFoundError:
            print("ERROR")
            
def r(dl): #kinda works, needs to print better 
    if type(dl) == list:
        for i in dl:
            emp_file.append(i)
            r(i)
    else:
        for i in dl.iterdir():
            if i.is_file():
                emp_file.append(i)
            elif i.is_dir():
                emp_file.append(i)
                r(i)

def f(file): #Works 
    for files in file:
        if files.is_file() == True:
            print(files)

def s(file):
    for i in file:
        if PurePath(i).name == extension_se:
            print(i)

def e(file): #needs to find extension    
    for i in file:
        pp = PurePath(i).suffix.replace(".","")
        if pp == extension_se:
            print(i)

def user(): #needs testing, optionind1 works, need to work on extension
    global optionind1, optionind2, command, extension_se, il
    inp = input().replace(" ", "")
    try:
        command = inp[0] #first command of the user 
    except IndexError:
        print("ERROR")
    il = list(inp) #list of user inputs with no spaces #EX L \ics32home -r -s .txt
    optionind1 = None ##--> to keep track of the varialbes 
    optionind2 = None
    optionindex = None
    user_path = None
    extension_se = None
    f_var = False

    for i in range(len(il)):
        if (il[i] == "-" and 
            (il[i+1] == "r" or il[i+1] == "f" or il[i+1] == "e" or il[i+1] == "s" or il[i+1] == "n")):
            optionind1 = il[i+1] #letter itself 
            optionindex = i+1 #number itself
            user_path = "".join(il[1:optionindex-1])
            f_var = True
            break
    if not f_var:
        user_path = "".join(il[1:]) #if true never hits 
        
    if optionind1 in ["s", "e"]: #checks to see if it is inside s or e 
        extension_se = "".join(il[i+2:]) #joins to a string for extension
    elif optionind1 == "r": #trys for r 
        try:
            if il[optionindex+2] in ["s", "e", "f"]: #trys for option"2"
                optionind2 = il[optionindex+2]
                extension_se = "".join(il[optionindex+3:]) #EX L\ics\home-r-f [to look at]
        except IndexError:
            pass
    try:
        if command == "C" and len(il) > 3:
            extension_path = il[optionindex+1:] #if C gives extension on where to create the file 
            opt_C(user_path,extension_path)
        elif command == "D" and len(il) > 3:#no extension runs D
            opt_D(user_path)
        elif command == "R" and len(il) > 3: #no extension runs R
            opt_R(user_path)
        elif command == "Q" and len(il) > 3: #quits the problem 
            return False
        elif command == "L" and len(il) > 3: #if it is L runs L function 
            opt_L(user_path)
        else:
            print("ERROR") #should be a wrong input 
    except (NameError,IndexError):
        None
    
def run():
    while True:
        user()
        if command == "Q":
            quit()

run()